import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:esc_pos_bluetooth/esc_pos_bluetooth.dart';


class ConnectPrinter extends StatefulWidget {
  _ConnectPrinter createState() => _ConnectPrinter();
}

class _ConnectPrinter extends State<ConnectPrinter> {

  PrinterBluetoothManager _printer = PrinterBluetoothManager();
  List <PrinterBluetooth> _devices =[];


  @override
  void initState() {
    super.initState();
    _getBluetoothDevices();
  }

  Future<void> _getBluetoothDevices() async {
    _printer.startScan(Duration(seconds: 4));
    _printer.scanResults.listen((event) {
      if(!mounted)return;
      setState(() {
        _devices=event;
        print(_devices);
      });
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Printer'),
      ),
      body: Container(
        child: ListView.builder(
          itemCount: _devices.length,
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              title: Text(_devices[index].name.toString()),
              subtitle: Text(_devices[index].address.toString()),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.bluetooth),
                ],
              ),
              onTap: () {
                //connectAndPrint(_devices[index].device);
              },
            );
          },
        ),
      ),
    );
  }

  // void connectAndPrint(BluetoothDevice device) async {
  //   printerDevice = device;
  //   await printerDevice!.connect(autoConnect: true);
  //   String text = "Connected!";
  //   List<int> printData = utf8.encode(text);
  //   await _writeCharacteristic(printData);
  //   await printerDevice!.disconnect();
  // }

  // Future<void> _writeCharacteristic(List<int> data) async {
  //   List<BluetoothService> services = await printerDevice!.discoverServices();
  //   for (BluetoothService service in services) {
  //     for (BluetoothCharacteristic characteristic in service.characteristics) {
  //       if (characteristic.properties.write) {
  //         await characteristic.write(data, withoutResponse: true);
  //         return;
  //       }
  //     }
  //   }
  //
  //   print('No writable characteristic found');
  // }
}
