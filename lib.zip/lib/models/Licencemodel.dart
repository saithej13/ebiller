class Licencemodel{
  int? ID;
  String BNAME;
  String FROMDATE;
  String TODATE;
  Licencemodel({this.ID,required this.BNAME,required this.FROMDATE,required this.TODATE});

  factory Licencemodel.fromMap(Map<String, dynamic> json) => new Licencemodel(
    ID: json["ID"],
    BNAME: json["BNAME"],
    FROMDATE: json["FROMDATE"],
    TODATE: json["TODATE"],
  );
  Map<String, dynamic>toMap(){
    return{
      'ID':ID,
      'BNAME':BNAME,
      'FROMDATE':FROMDATE,
      'TODATE':TODATE,
    };
  }
}